﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CorpMessengerBackend.Migrations
{
    public partial class tttttt : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
